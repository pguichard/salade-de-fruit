public class Banane extends Fruit{

    private String longeur;

    public Banane(String longeur, String origine) {
        super ("Banane", "jaune", origine);
        this.longeur = longeur;
    }

    public String getLongeur() {
        return longeur;
    }

    public void setLongeur(String longeur) {
        this.longeur = longeur;
    }
}
