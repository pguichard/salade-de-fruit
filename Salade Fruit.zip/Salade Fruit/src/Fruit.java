public class Fruit {

    private String name;

    private String couleur;

    private String origine;

    public Fruit(String name, String couleur, String origine) {
        this.name = name;
        this.couleur = couleur;
        this.origine = origine;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCouleur() {
        return couleur;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public String getOrigine() {
        return origine;
    }

    public void setOrigine(String origine) {
        this.origine = origine;


    }
}
