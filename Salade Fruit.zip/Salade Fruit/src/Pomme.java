public class Pomme extends Fruit{

    private String circonferance;


    public Pomme(String circonferance, String origine) {
        super("Pomme", "verte", origine);
        this.circonferance = circonferance;
    }

    public String getCirconferance() {
        return circonferance;
    }

    public void setCirconferance(String circonferance) {
        this.circonferance = circonferance;
    }
}
