import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args){

        Banane banane = new Banane("15cm", "Inde");
        Banane banane2 = new Banane("17cm", "Inde");
        Pomme pomme = new Pomme("7cm",  "France");
        Pomme pomme1 = new Pomme("7cm",  "France");
        Pomme pomme2 = new Pomme("7cm",  "France");
        Pomme pomme3 = new Pomme("7cm",  "France");
        Pomme pomme4 = new Pomme("7cm",  "France");
        Fraise fraise = new Fraise(  "250g","France");
        Fraise fraise1 = new Fraise(  "250g","France");
        List<Fruit> fruits = Arrays.asList(pomme, pomme1, pomme2, pomme3, pomme4, fraise,fraise1,banane,banane2);


        SaladeFruit saladeFruit = new SaladeFruit(fruits);
        saladeFruit.printFruits();

        saladeFruit.printFruits2();

    }
}

