public class Fraise extends Fruit {

    private String poids;

    public Fraise(String poids, String origine) {
        super("Fraise","Rouge",origine);
        this.poids = poids;
    }

    public String getpoids() {
        return poids;
    }

    public void setpoids(String poids) {
        this.poids = poids;
    }
}
