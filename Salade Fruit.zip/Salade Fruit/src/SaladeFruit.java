import com.sun.jdi.Value;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SaladeFruit {

    private List<Fruit> fruits;

    public SaladeFruit(List<Fruit> fruits) {
        this.fruits = fruits;
    }

    public List<Fruit> getFruits() {
        return fruits;
    }

    public void setFruits(List<Fruit> fruits) {
        this.fruits = fruits;
    }

    public void printFruits() {
        List<Fraise> fraises = new ArrayList<>();
        List<Pomme> pommes = new ArrayList<>();
        List<Banane> bananes = new ArrayList<>();
        for (Fruit fruit : fruits) {
            if (fruit != null) {
                if (fruit instanceof Pomme) {
                    pommes.add((Pomme) fruit);
                }
                if (fruit instanceof Banane) {
                    bananes.add((Banane) fruit);
                }
                if (fruit instanceof Fraise) {
                    fraises.add((Fraise) fruit);
                }
            };
        }
        System.out.println(fraises.size()+" Fraise(s)");
        System.out.println(pommes.size()+" Pomme(s)");
        System.out.println(bananes.size()+" Banane(s)");
    }

    public void printFruits2() {
        Map<String, List<Fruit>> map = new HashMap<>();
        for (Fruit fruit : fruits) {
            if (fruit != null) {
                List<Fruit> fruitList = map.get(fruit.getClass().getSimpleName());

                map.put(fruit.getClass().getSimpleName(), List.of(fruit));
            }
        }
        for (Map.Entry<String, List<Fruit>> entry : map.entrySet()) {
            System.out.println(entry.getValue().size()+" "+entry.getKey());
        };
    }
}
